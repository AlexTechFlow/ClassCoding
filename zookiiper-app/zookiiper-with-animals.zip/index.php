<?php ?>
<!doctype html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <title>Zoo Homepage</title>
        <meta name="description" content="">
        <link rel="stylesheet" href="css/main.css">
    </head>
    <body>
    	<nav>
    		<ul>
    			<li><a href="select-zoo.php">Zoos</a></li>
    			<li><a href="insert-zoo-form.html">Add Zoo</a></li>
    		</ul>
    	</nav>
        <nav>
            <ul>
                <li><a href="select-animal.php">Animal</a></li>
                <li><a href="insert-animal-form.html">Add Animals</a></li>
            </ul>
        </nav>
        
    	<h1>Homepage</h1>

    </body>
</html>